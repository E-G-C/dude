# Crew Decisions

Durable project and process decisions that Crew should preserve.

## Entries

- `brainstorm/<slug>.md` is the file-based intake ledger before promotion.
- Feature definition is handled natively inside Crew under `specs/<feature>/`.
- `@crew start working` is the normal handoff from promoted features into Beads; explicit import prompts are a manual fallback.
- Tracked execution uses Beads as the single live work board.
- Parallel execution is an internal Crew responsibility during Beads work, not a user-managed workflow step.
- Git worktrees are opt-in, not part of the default workflow.
- TDD is opt-in, not a global rule.
- The Electron POC markdown editor behavior is the approved baseline for the Tauri rewrite; preserve its WYSIWYG markdown editing model and overall interaction pattern unless a later product decision explicitly changes it.
