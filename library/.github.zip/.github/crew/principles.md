# Crew Principles

Stable principles, constraints, and working preferences that Crew should follow.

## Entries

- Once execution work is imported, Beads is the only live tracker for pending and completed work.
- Keep intent separate from implementation: `spec.md` stays technology-agnostic, while `plan.md` carries technical design.
- Optional disciplines such as worktrees and TDD are opt-in unless the user explicitly adopts them for the project.
