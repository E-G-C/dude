# Crew Lessons

Solved challenges, learned patterns, and candidate future skills.

## Entries

- Require an explicit `specs/<feature>/` path when multiple feature directories exist; do not guess.
- Stop import on malformed or ambiguous `tasks.md` lines instead of inferring intent.
- Do not keep using `tasks.md` as the live board after import into Beads.
- Keep optional operational tooling clearly marked as opt-in to avoid accidental workflow drift.
