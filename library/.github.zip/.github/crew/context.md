# Crew Context

Durable domain knowledge, project facts, and important background context.

## Entries

- This repository's primary deliverable is ImpacTally, a Tauri/Rust desktop app for Microsoft employees to track work impact and generate Connect documents.
- Empty or missing `brainstorm/` and `specs/` directories are valid; feature directories are created when definition work starts.
- Beads commands should use `--json` whenever output will be parsed or used for coordination.
- UI mockups in `brainstorm/media/` (image.png through image-5.png) are authoritative references for layout, component choices, and interaction patterns. Specialists should consult them during UI design and implementation.
- The primary Electron/React POC lives at `C:\Work\AI\ImpactTracker\impactally\desktop\` — use it as the authoritative reference for shell layout, nav drawer composition, and workflow behavior; the new project is a full Rust/Tauri rewrite (no migration).
- A secondary earlier POC exists at `c:\work\AI\ImpactTracker\it1\` with similar patterns.
- The Electron POC uses React 19 with Fluent UI React v9 and should guide component selection, navigation layout, and theming direction for the Tauri rewrite.
- The Electron POC uses a Fluent `NavDrawer` with five destinations (Browse, Evidence, Connect, Collector, Settings) plus a Utility group and a hamburger-collapsible icon rail as the primary shell destination switcher. This is the approved nav model for the Tauri rewrite.
- The Electron POC uses Milkdown as a WYSIWYG markdown editor that preserves markdown on disk; it is the approved reference for editor behavior in the Tauri rewrite.
- The Electron POC already demonstrates browse, calendar filtering, search, merge/accumulate, evidence gathering, Connect generation, and collector management workflows; use those flows as behavioral references alongside the mockups.
