---
name: "parallel-dispatch"
description: "Use when several subtasks may run independently, when deciding between sequential and parallel specialist dispatch, when automatically fanning out ready Beads work, or when coordinating multi-agent fan-out."
---

## Purpose

Use parallelism only when it is safe, useful, and deterministic.

## Safe Parallelism Conditions

Parallel dispatch is appropriate when:

- the tasks are already ready in Beads or otherwise explicitly unblocked
- subtasks are independently scoped
- there is no unresolved blocker between them
- they do not obviously compete for the same files or artifact ownership
- one subtask does not need the output of another first

## Automatic Fan-Out Rules

- Preserve Beads ready order as the default dispatch order.
- Launch at most 2 specialists in parallel by default unless the user explicitly asks for more.
- Prefer tasks from different features or clearly separate artifact areas.
- Do not parallelize tasks that touch the same brainstorm file, the same spec package, or the same implementation files unless independence is explicit.
- After each execution round, re-query Beads before dispatching more work.

## Good Uses

- two specialists working on independent deliverables with no shared artifacts
- implementation work and review preparation on unrelated items
- separate investigations in different problem areas

## Bad Uses

- concurrent edits to the same artifact
- concurrent edits to the same brainstorm file or definition package
- review before implementation is complete
- tasks with unclear ownership boundaries
- work that depends on the output of another specialist not yet finished
- sequential steps that must land in order

## Output Pattern

When dispatching in parallel, state:

- which specialists are being launched
- what each one owns
- why the parallel split is safe
- what capped the fan-out size, if not all ready tasks were dispatched
