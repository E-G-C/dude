---
name: "generic-routing"
description: "Use when matching a user request or subtask to the right specialist agent in the Crew roster."
---

## Purpose

Route requests to the smallest appropriate specialist set, regardless of domain.

## Routing Algorithm

1. **Discover the roster**: list all `.agent.md` files under `.github/agents/` (excluding `crew.agent.md`).
2. **Read each agent's scope**: compare the agent's `description` and `## Scope` section against the task.
3. **Match by keyword overlap**: the agent whose scope keywords best match the task gets the work.
4. **Prefer narrow over broad**: if two agents could handle it, pick the one with the more specific scope.
5. **No match**: if no specialist fits, ask the user whether to handle it directly or hire a new agent.

## Tie Breakers

- Prefer one specialist if one can credibly own the task.
- Split only when the domains are meaningfully different.
- Do not route review or acceptance to the implementation author.
- If a newly hired specialist matches the task more closely than an older one, prefer the new specialist.
- When uncertain, check crew memory for past routing decisions.

## Authority Ownership

Maintain explicit owners for:

- **Planning authority** — assign to the specialist whose scope best covers planning, structure, and design tradeoffs.
- **Quality authority** — assign to the specialist whose scope best covers independent review and acceptance.

Mode-specific defaults:

- During feature definition under `specs/<feature>/`, default planning authority to `@spec-lead`.
- After Beads import, default planning authority to `@lead` for implementation structure and execution tradeoffs.
- When a dedicated independent reviewer exists, default quality authority to that reviewer.

If the current owner is removed, replaced, or no longer the best fit, update the coordinator's routing guidance explicitly. If no clear owner exists, escalate to the user instead of inventing one.

## Conflict Resolution

When specialists disagree:

- the current planning authority has final say on structure and design questions
- the current quality authority has final say on acceptance and readiness
- if the disagreement spans both domains, escalate to the user

## Dynamic Roster Rule

The roster is whatever currently exists under `.github/agents/`. There are no permanent defaults. When agents are added or removed, the routing adapts automatically based on their scope descriptions.
