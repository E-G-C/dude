---
name: "crew-portability"
description: "Use when saving, exporting, importing, or deploying a Crew bundle across repositories or directories."
---

## Purpose

Preserve Crew as a portable markdown-only bundle.

## Save Or Export

When saving the Crew bundle:

1. copy `.github/agents/`
2. copy `.github/skills/`
3. copy `.github/crew/`
4. copy `.github/copilot-instructions.md`
5. place them into a portable destination such as `crew/` or another requested path
6. note any runtime-specific frontmatter assumptions that may need adaptation in the destination host
7. confirm what was exported

## Deploy Or Import

When deploying a Crew bundle into a project:

1. read the source bundle
2. copy agents, skills, memory, and instructions into the target `.github/` structure
3. adapt runtime-specific frontmatter such as `model` and `tools` when the target host differs from the source host
4. verify the coordinator and routing files exist after copy
5. confirm what was imported

## Guardrails

- do not overwrite intentionally customized files without user approval when the destination already contains a Crew bundle
- keep the `.github` structure intact for portability
- prefer merge or update behavior over blind replacement when both source and destination have meaningful customizations
- portability means the markdown bundle should travel cleanly even when frontmatter details need host-specific translation
