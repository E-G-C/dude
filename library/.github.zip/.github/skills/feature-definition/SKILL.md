---
name: feature-definition
description: "Use when ingesting a brainstorm file, promoting a brainstorm into specs/<feature>/, defining a new feature, clarifying requirements, writing spec.md, planning implementation, deriving tasks.md, or analyzing consistency."
---

# Feature Definition

Crew owns feature definition natively. This skill defines the file-based brainstorm intake plus the internal spec -> plan -> tasks workflow that starts at promotion.

## Purpose

Maintain a single brainstorm ledger under `brainstorm/<slug>.md`, then create a complete reusable definition package under `specs/<feature>/` when the feature is promoted.

## Brainstorm Intake File

Before promotion, keep feature intake in:

```text
brainstorm/
└── feature-name.md
```

Use this structure:

```markdown
---
title: Feature title
slug: feature-name
status: brainstorm
spec_path:
---

# Brainstorm: Feature title

## User Draft
[raw user input]

## Normalized Intent
- [Crew-maintained bullets]

## Constraints
- [constraints, non-goals, dependencies]

## Open Questions
- [focused clarification question]

## Assumptions
- [reasonable defaults]

## Promotion Checklist
- [ ] Outcome is clear
- [ ] Scope is bounded
- [ ] Open questions are resolved or consciously assumed

## Promotion Record
- Not promoted yet
```

Keep `## User Draft` intact. Use the other sections to drive clarification and readiness.

## Feature Directory

Write feature artifacts under:

```text
specs/
└── 001-feature-name/
    ├── spec.md
    ├── plan.md
    ├── research.md
    ├── data-model.md
    ├── quickstart.md
    ├── tasks.md
    ├── contracts/
    │   ├── api.md
    │   └── schemas.md
    └── checklists/
        ├── ux.md
        ├── test.md
        └── security.md
```

Number features sequentially by scanning existing `specs/` folders and using the next available prefix.

When promotion succeeds, write the chosen `spec_path` back into the brainstorm file and set `status: promoted`.

## Step 0: Ingest And Maintain `brainstorm/<slug>.md`

On `ingest` or other early-stage requests:

1. Create or identify `brainstorm/<slug>.md`.
2. Preserve the raw user draft in `## User Draft`.
3. Normalize the requested outcome in `## Normalized Intent`.
4. Record constraints, assumptions, and open questions in the same file.
5. Keep the file in `status: brainstorm` until promotion is requested.
6. Do not create `specs/<feature>/` yet unless the user has asked for promotion or the workflow explicitly moves to that stage.

## Step 1: Write `spec.md`

`spec.md` defines WHAT to build and WHY. It must be technology-agnostic — no languages, frameworks, or API details.

Promotion creates or refreshes the standard package under `specs/<feature>/`. From that point onward, the internal workflow stays the same.

### Required Sections (in order)

#### User Scenarios & Testing

Prioritized user stories ordered by importance. Each story must be independently testable — implementing just one should deliver a viable MVP slice.

For each story:

- **Title and priority** (`P1`, `P2`, `P3`)
- **Why this priority**: value justification
- **Independent test**: how to verify it works on its own
- **Acceptance scenarios**: Given/When/Then format

```markdown
### User Story 1 — [Title] (Priority: P1)

[Plain language description]

**Why this priority**: [value justification]

**Independent Test**: [how to verify this story alone]

**Acceptance Scenarios**:

1. **Given** [state], **When** [action], **Then** [outcome]
2. **Given** [state], **When** [action], **Then** [outcome]
```

#### Edge Cases

Boundary conditions and error scenarios the spec must address.

#### Functional Requirements

Numbered, testable requirements:

- `FR-001`: System MUST [capability]
- `FR-002`: Users MUST be able to [interaction]

#### Key Entities (when data is involved)

Domain objects, relationships, and key attributes — without implementation details.

#### Success Criteria

Measurable, technology-agnostic outcomes:

- `SC-001`: [quantitative or qualitative measure]
- `SC-002`: [verifiable without implementation details]

#### Assumptions

Reasonable defaults for unspecified details. Document what was assumed and why.

### Clarification Rules

- Mark genuine ambiguity with `[NEEDS CLARIFICATION: specific question]`.
- **Maximum 3 markers per spec.** Prioritize by impact: scope > security/privacy > user experience > technical details.
- For everything else, make an informed default and document it in Assumptions.
- Do not plan or derive tasks until all markers are resolved.

## Step 2: Write `plan.md`

`plan.md` defines HOW to build the feature.

### Required Sections

#### Summary

One paragraph: primary requirement plus technical approach.

#### Technical Context

Fill these fields (mark unknowns as `NEEDS CLARIFICATION`):

```markdown
**Language/Version**: [e.g., Python 3.11, TypeScript 5.x]
**Primary Dependencies**: [e.g., FastAPI, React]
**Storage**: [e.g., PostgreSQL, SQLite, N/A]
**Testing**: [e.g., pytest, vitest]
**Target Platform**: [e.g., Linux server, browser, iOS]
**Project Type**: [e.g., library, CLI, web-service, mobile-app]
**Performance Goals**: [domain-specific or NEEDS CLARIFICATION]
**Constraints**: [domain-specific or NEEDS CLARIFICATION]
```

#### Constitution Check

Validate against `.github/crew/principles.md`. Gate: must pass before research begins. Re-check after design.

#### Project Structure

Concrete directory layout for this feature (not options — a single chosen structure with rationale).

#### Complexity Tracking

Only if the constitution check has violations that must be justified:

```markdown
| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
```

#### Phases

High-level phase breakdown that will feed into `tasks.md`.

## Step 2a: Validate Spec Before Planning

Before writing `plan.md`, validate `spec.md` against these criteria:

- No implementation details (languages, frameworks, APIs) in the spec
- All mandatory sections completed
- Requirements are testable and unambiguous
- Success criteria are measurable and technology-agnostic
- All acceptance scenarios defined
- Edge cases identified
- No unresolved `[NEEDS CLARIFICATION]` markers remain

If validation fails, fix the spec first. Maximum 3 validation-fix iterations before warning the user.

## Step 3: Write Supporting Artifacts

Create only the artifacts the feature actually needs:

- `research.md` for technical decisions and unknowns
- `data-model.md` for entities and relationships
- `contracts/api.md` for endpoints and shapes
- `contracts/schemas.md` for validation or shared data contracts
- `quickstart.md` for key validation paths
- `checklists/` for focused domain checks when useful

## Step 4: Derive `tasks.md`

`tasks.md` converts the plan into executable work.

### Task Format

Each task follows this format:

```markdown
- [ ] T001 [P] [US1|Shared] Description with file paths
```

- `T001` — sequential task ID
- `[P]` — parallel-safe (no dependencies within phase)
- `[US1]` — maps to User Story 1 from `spec.md`
- `[Shared]` — setup, foundational, or polish work that supports multiple stories
- Description should include concrete file paths when possible

### Phase Pattern

Use this sequence when it fits the feature:

1. **Phase 1: Setup** — project initialization and basic structure
2. **Phase 2: Foundational** — blocking prerequisites for all stories (no story work until this phase is complete)
3. **Phase 3+: User Story N** — one phase per user story, in priority order from `spec.md`
4. **Final: Polish** — cross-cutting concerns

Setup, foundational, and polish tasks may use `[Shared]` instead of a story label when they unblock multiple stories.

Each user story phase includes:

- **Goal**: brief description of what the story delivers
- **Independent Test**: how to verify this story on its own
- **Tests** (optional, only if requested): test tasks FIRST, ensure they fail, then implementation
- **Implementation**: concrete tasks with file paths
- **Checkpoint**: "At this point, User Story N should be fully functional"

### Priority Mapping (for Beads import)

- P1 story tasks → priority 1 (high)
- P2 story tasks → priority 2 (medium)
- P3 story tasks → priority 3 (low)
- Setup/foundational → priority 1
- Polish → priority 3

### Dependency Rules

- Tasks marked `[P]` within a phase have no blocking dependencies on each other.
- Non-`[P]` tasks depend on all earlier tasks in the same phase.
- Cross-phase: every task in Phase N+1 depends on ALL tasks of Phase N completing.
- Do not invent dependencies from mere adjacency — only where a real blocker exists.

## Step 5: Analyze Consistency

Before handoff, verify:

- every task traces to a real plan decision or requirement
- every plan section traces to the spec
- contracts match the plan
- no unresolved clarification markers remain
- each user story is independently testable
- tasks do not invent scope absent from the spec

## Handoff To Beads

After the definition package is clean:

1. Tell the coordinator the feature is promoted and ready.
2. If architecture sanity is useful, route the package to `@lead`.
3. If an independent readiness judgment is needed, route the package to `@reviewer`.
4. Do not route definition packages to `@tester` by default.
5. The normal workflow lets `@crew start working` import promoted features into Beads automatically.
6. Explicit manual import is a fallback when the user asks for it.
7. Treat Beads as the live execution board after import.

## Guardrails

- Do not split one feature across multiple brainstorm files unless the user wants separate promoted packages.
- Do not hide pre-spec clarification in chat when it belongs in the brainstorm file.
- Do not bury execution state in markdown after Beads import.
- Do not mix implementation code into spec artifacts.
- Do not skip clarification when the spec is materially ambiguous.
- Do not derive tasks before the plan is coherent.
- Do not let `tasks.md` drift away from the plan.