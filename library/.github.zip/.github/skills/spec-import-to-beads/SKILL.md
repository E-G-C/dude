---
name: spec-import-to-beads
description: "Use when importing feature tasks from specs/ into Beads, automatically importing promoted feature packages during @crew start working, converting tasks.md into issues, mapping user stories to tasks, or creating Beads dependencies from Crew-defined feature artifacts."
---

# Spec Import To Beads

How to read Crew-defined feature artifacts and import them into Beads.

Promoted brainstorm files may point at definition packages through `spec_path:`. The coordinator can use that pointer for automatic import during `@crew start working`.

## Feature Directory Structure

Crew writes feature definitions under `specs/`:

```text
specs/
└── 001-feature-name/
    ├── spec.md
    ├── plan.md
    ├── research.md
    ├── data-model.md
    ├── tasks.md
    ├── contracts/
    │   ├── api.md
    │   └── schemas.md
    └── quickstart.md
```

## Reading Definition Artifacts

### `spec.md`

- prioritized user stories
- acceptance criteria in Given/When/Then format
- functional requirements
- edge cases
- key entities

### `plan.md`

- architecture
- project structure
- technical choices
- implementation phases

### `tasks.md`

- `T001` style task IDs
- `[P]` for parallel-safe tasks
- `[US1]`, `[US2]` story labels
- `[Shared]` for cross-story setup, foundational, or polish work
- phased ordering

Every executable task line must follow one unambiguous format. If a line is malformed or mixes conflicting labels, stop the import and fix `tasks.md` first.

## Active Feature Selection

### Automatic mode (`@crew start working`)

- Scan `brainstorm/` for files with `status: promoted` and a populated `spec_path:`.
- For each promoted entry whose `spec_path` is not yet represented in Beads, import that feature automatically.
- Use the brainstorm file as the authoritative pointer during this automatic handoff.
- Do not ask the user for a `specs/<feature>/` path during this automatic mode.

### Manual mode (explicit import prompt)

- If the user provides an explicit `specs/<feature>/` path, use it.
- Else if exactly one feature directory exists under `specs/`, use it.
- Else ask the user to specify the feature path explicitly.
- Do not guess when multiple feature directories exist in manual mode.

## Import Algorithm

1. Select the feature directory using the rules above.
2. Read `spec.md` to extract feature intent and user stories.
3. Read `plan.md` to extract architecture, structure, and stack choices.
4. Read `tasks.md` to extract executable tasks and ordering. If any task line is malformed, ambiguous, or carries conflicting story labels, stop and request a corrected `tasks.md` before import.
5. Create one Beads epic for the feature if not already represented. Keep it out of the ready queue by creating it as backlog or deferred work, for example with `-p 4 --defer +30d`.
6. Create Beads task issues for executable checklist items using `--spec-id "specs/<feature>/spec.md"` so the imported work stays linked to the source package.
    Do not attach imported task issues to the epic with `--parent` or any `parent-child` dependency. In Beads, that relationship blocks readiness; keep grouping via `spec_id`, labels, and issue descriptions instead.
7. Preserve these details in each issue description:
   - original task ID (e.g., `T012`)
   - story label (e.g., `US1`)
   - relevant file paths
   - acceptance hints or checkpoint text
   - source artifact path
8. Set the Beads `spec_id` field to the promoted spec path so automatic feature handoff can detect that the package is already represented in Beads.
9. Derive dependencies using the task structure rules:
    - every task in Phase N+1 depends on all tasks in Phase N
    - non-`[P]` tasks depend on all earlier tasks in the same phase
    - `[P]` tasks do not depend on sibling tasks unless the source text states a real blocker
10. Report created issue count, dependency count, and actionable ready task count.

## Mapping Rules

- feature title -> Beads epic title
- user story -> label, section marker, or child grouping in issue description
- `[Shared]` -> setup/foundational/polish work not tied to a single user story
- task checklist item -> Beads task issue
- `[P]` marker -> parallel-eligible within the phase
- checkpoint text -> acceptance or completion notes

## Priority Mapping

When creating Beads issues, translate spec priorities:

- P1 story tasks → `bd -p 1` (high)
- P2 story tasks → `bd -p 2` (medium)
- P3 story tasks → `bd -p 3` (low)
- Setup/foundational tasks → `bd -p 1`
- Polish tasks → `bd -p 3`

## Guardrails

- Do not auto-import from `@crew status` or other read-only commands.
- Do not guess a promoted feature when the brainstorm file is missing `spec_path:` or points to a missing package.
- Do not leave the feature epic as actionable ready work. Defer it or otherwise keep it out of `bd ready` selection.
- Do not continue to use `tasks.md` as the live execution board after import.
- Do not attach imported task issues to the feature epic with `--parent` or any other `parent-child` dependency; it blocks the ready queue.
- Do not skip phase gating: later-phase tasks must not become ready before the prior phase is complete.
- Do not invent extra sibling dependencies beyond what `[P]`, ordering, and source text justify.
- Do not guess at malformed task lines. Stop import and request a corrected `tasks.md` when task IDs, labels, or phase structure are ambiguous.
- Do not collapse multiple materially different tasks into one issue unless the source task is too granular to execute independently.
- When something in the spec is ambiguous, resolve it before import instead of guessing.
- `spec.md` is the source of truth for WHAT to build; `plan.md` is the source for HOW.