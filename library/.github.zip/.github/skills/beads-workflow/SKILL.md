---
name: beads-workflow
description: "Use when working with Beads issue tracking: bd ready, bd create, bd update, bd close, claiming tasks, resume-first execution, pending work, blocked work, discovered bugs, or execution status."
---

# Beads Workflow

Standard workflow for all Crew specialists when working on tasks tracked in Beads.

## Coordinator Handoff

- `@crew start working` normally resumes in-progress work first.
- Before selecting new work, the coordinator may import promoted brainstorms whose `spec_path` is not yet represented in Beads.
- `@crew status` reports Beads state and promoted features waiting for execution, but it must not import or mutate work.

## Feature Lifecycle After Import

- A feature is considered `imported` once at least one Beads issue references its `spec_id`.
- A feature is considered `active` when it currently has ready or in-progress Beads work.

## Before Starting Work

```bash
# Find your next task (coordinator usually tells you, but you can check)
bd ready --json --limit 5
```

Ignore epics or other non-executable grouping issues if they appear in the ready output.

## Claiming a Task

Always claim before starting. This is atomic — prevents two agents from working on the same task.

```bash
bd update <id> --claim --json
```

If the claim fails (someone else got it first), pick the next ready task.

## Reading Context

Every bead has a `spec_id` field linking to the specification document. Always read it before starting:

```bash
bd show <id> --json
# → check spec_id field → read that file for acceptance criteria, plan, and contracts
```

Also check for related context:

- `specs/<feature>/plan.md` — technical architecture
- `specs/<feature>/contracts/` — API contracts, schemas
- `specs/<feature>/data-model.md` — entity definitions

## During Work

If you discover a bug, missing requirement, or new task while working:

```bash
bd create "<title>" -t bug -p <priority> --deps discovered-from:<current-task-id> --json
```

The `discovered-from` link maintains traceability. The new bead enters the ready queue after the current task closes.

## Completing a Task

When the work is done:

```bash
bd close <id> --reason "Completed: <one-line summary of what was done>" --json
```

This automatically unblocks any tasks that were waiting on this one.

## Status Values

| Status | Meaning |
|--------|---------|
| `open` | Ready to be claimed |
| `in_progress` | Claimed, being worked on |
| `blocked` | Waiting on another task |
| `deferred` | Intentionally postponed |
| `closed` | Done |

## Priority Values

| Priority | Meaning |
|----------|---------|
| 0 | Critical — security, data loss, broken builds |
| 1 | High — major features, important bugs |
| 2 | Medium — standard work |
| 3 | Low — polish, optimization |
| 4 | Backlog — future ideas |

## Rules

- Always use `--json` flag for reliable output parsing.
- Never create tasks outside Beads — it is the single source of truth.
- Always claim before working — never skip the claim step.
- Always close with a reason — this becomes the audit trail.
- Ignore epics or other grouping issues in `bd ready` output; they are not executable tasks.
- If you can't complete a task, update its status: `bd update <id> --status blocked --json`

## Ready Work Loop

1. Query `bd ready --json`.
2. Filter out epics or other non-executable grouping issues.
3. Pick one or more safe tasks.
4. Execute and validate.
5. Close or update status.
6. Query ready work again.
