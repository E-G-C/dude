---
name: using-git-worktrees
description: "Use when the user explicitly asks for a git worktree, isolated branch workspace, parallel checkout, or branch-safe implementation area for risky or independent work."
---

# Using Git Worktrees

## Purpose

Set up an isolated git worktree when isolation itself is the task.

This skill is optional. It is not part of Crew Coder's default workflow.

## Use When

- the user explicitly asks for a worktree
- the user wants isolated branch work for a risky refactor
- the user wants separate checkouts for parallel implementation work
- the user wants to protect the current working tree while trying a change

## Do Not Use When

- normal work can happen in the current checkout
- the request is only to define a feature or import work into Beads
- the user did not ask for isolation and there is no clear isolation requirement

Beads still remains the live execution board. A worktree only changes where code is edited.

## Directory Selection

Use this order:

1. If `.worktrees/` exists, prefer it.
2. Else if `worktrees/` exists, use it.
3. Else ask the user where to place worktrees.

Recommended options to offer:

1. `.worktrees/` inside the repo
2. `worktrees/` inside the repo
3. another explicit path the user prefers

## Safety Rules

If using a repo-local directory such as `.worktrees/` or `worktrees/`:

1. Verify the directory is ignored before creating the worktree.
2. If it is not ignored, add the ignore entry first.
3. Do not create the worktree until ignore coverage is clear.

Use `git check-ignore` to verify ignore behavior.

## Windows Notes

- Use PowerShell-friendly commands when working in this environment.
- Prefer paths relative to the repository root where possible.
- Quote paths with spaces.
- Use `git worktree add <path> -b <branch>` normally; no Windows-specific git flags are required.

## Setup Steps

1. Determine the repository root and project name.
2. Choose the worktree directory using the rules above.
3. Verify ignore coverage if the directory is repo-local.
4. Create a branch name that reflects the task.
5. Run `git worktree add <path> -b <branch>`.
6. Move into the worktree and run lightweight setup only if needed for the project.
7. If practical, run a baseline verification command before starting implementation.

## Return Pattern

Report:

- worktree path
- branch name
- whether ignore coverage was verified or changed
- any baseline verification run
- whether the user should continue work in the new worktree or the current checkout