---
name: story-routing
description: "Use when routing Beads issues or user requests to specialists, matching issue text to spec-lead or backend or frontend or tester or reviewer or lead roles, or deciding who should own ready work next."
---

# Story Routing

Pick the best specialist for a ready Beads issue based on its title, description, labels, and source references.

## Routing Heuristics

### Route To Spec Lead

Keywords and signals:

- brainstorm, ingest, promote
- define feature, write spec, specify
- clarify requirements, resolve ambiguity
- create plan, implementation plan
- derive tasks, break down feature
- analyze consistency, spec quality
- `specs/<feature>/` artifacts

### Route To Lead

Keywords and signals:

- architecture, scaffolding, project setup
- design decision, trade-off
- module boundaries, configuration
- Phase 1 (Setup) or Phase 2 (Foundational) labels

### Route To Backend

Keywords and signals:

- API, endpoint, database, schema, migration
- auth, service, repository, integration
- middleware, validation, server
- backend file paths

### Route To Frontend

Keywords and signals:

- UI, page, component, form
- accessibility, layout, styling, responsive
- interaction, client-side state, navigation
- frontend file paths

### Route To Tester

Keywords and signals:

- test, regression, edge case
- validation, acceptance, coverage
- contract verification, QA, E2E

### Route To Reviewer

Keywords and signals:

- review, approve, reject
- readiness, final acceptance
- definition package readiness, import readiness
- spec compliance, quality gate

## Tie-Breaking Rules

- If the request is about defining, specifying, planning, or deriving tasks for a feature, prefer spec-lead.
- If the issue is mostly implementation, prefer backend or frontend over tester.
- If the issue is explicitly about validation, prefer tester.
- If the issue is about independent judgment after implementation, prefer reviewer.
- If the issue mixes backend and frontend work, split it into multiple Beads issues if the pieces can be executed independently.
- If the issue is about project structure or tooling, prefer lead.

## Coordinator Summary Pattern

When routing, state:

- issue ID
- short task name
- assigned specialist
- one-line reason for the assignment
