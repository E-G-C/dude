---
name: "work-intake"
description: "Use when triaging a new request, deciding whether to answer directly or route it, checking whether clarification is needed, ingesting early feature drafts into brainstorm files, or deciding whether a brainstorm file is ready to promote."
---

## Purpose

Establish a lightweight intake flow for Crew Coder work, including the file-based brainstorm stage.

## Intake Questions

For each request, decide:

1. Is this a direct answer or specialist work?
2. Is this raw product input that should become or update `brainstorm/<slug>.md`?
3. Is the request single-domain or multi-domain?
4. Is there enough information to act?
5. Is the brainstorm file ready to promote into `specs/<feature>/`?
6. Does the project already define a stronger process to follow?
7. Does crew memory contain relevant decisions, principles, or context?

## Memory Check

Before routing any work, scan `.github/crew/` for entries that apply to the
incoming request. Include relevant memories in the delegation context so
specialists don't contradict past decisions or repeat solved problems.

## Brainstorm Intake

- Keep one working ledger per feature under `brainstorm/<slug>.md`.
- Preserve the raw user draft inside `## User Draft`.
- Put Crew normalization, assumptions, open questions, and the promotion checklist in the same file.
- If clarification is needed, keep it in the brainstorm file instead of scattering it across chat.
- The user may answer by editing the same file and asking Crew to ingest it again.

## Promotion Gate

A brainstorm file is ready to promote when:

- the core user outcome is clear
- open questions are resolved or captured as conscious assumptions
- the feature is scoped tightly enough to become one `specs/<feature>/` package
- the user has asked Crew to promote it, or the workflow explicitly calls for promotion

## Default Handling

- Direct factual requests -> answer directly.
- Raw product or PRD input -> route to one brainstorm file and keep the conversation anchored there.
- Single-domain work -> route to one specialist.
- Multi-domain work -> decompose before routing.
- Promoted brainstorms -> route to `@spec-lead` for the standard definition package.
- Missing critical information -> ask one concise clarification question or add one focused question to the brainstorm file.

## Avoid

- asking broad exploratory questions when a narrow one will unblock the task
- inventing process overhead for simple requests
- splitting one feature across several intake files without a clear reason
- forcing decomposition when one specialist can handle the work
- ignoring existing team decisions or principles
