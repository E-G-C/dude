---
name: "project"
description: "Project-specific domain knowledge, conventions, and patterns. Update this skill as the project evolves so Crew and specialists can use it as shared context."
---

# Project Knowledge

> Fill this file with your project's domain, conventions, and working patterns.
> Delete the placeholder sections that don't apply and add your own.

## Project Shape

- **Domain**: (describe what this project is about — software, event planning, research, content, etc.)
- **Primary artifacts**: (what does the team produce? code? documents? plans? designs?)
- **Coordinator**: `@crew` owns routing, memory, skills, and team management
- **Current roster**: (list the specialists the user has hired)

## Working Conventions

> Add conventions specific to your domain. Examples:
>
> - Naming rules, file organization, style guides
> - Approval workflows, handoff protocols
> - Tools, platforms, or services the team uses
> - Quality standards or checklists

## Domain Knowledge

> Add project-specific terms, rules, constraints, and important background.
> This section helps specialists make informed decisions without re-asking.
