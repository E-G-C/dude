# Copilot Instructions — Crew Coder

This workspace uses the Crew model under `.github/` with native feature definition and Beads-based execution tracking.

The coordinator (`@crew`) is defined in `.github/agents/crew.agent.md` and owns
all routing, memory, skill, and team-management logic. These workspace-level
instructions provide only the shared rules that apply to **every** agent.

## Core Rules

1. Use the coordinator for routing, memory, and team management; specialists own domain work.
2. Prefer existing project conventions over built-in Crew defaults.
3. Do not assume a specific issue tracker, specification system, or backlog model unless the project explicitly documents one.
4. Do not create duplicate planning, tracking, or state files unless the user asks for them.
5. The coordinator may directly edit Crew-maintenance artifacts under `.github/`; project work should be routed to specialists by default.

## Brainstorm + Feature Definition + Beads

1. Crew accepts early feature input in `brainstorm/<slug>.md` and promotes it into `specs/<feature>/`.
2. The `@spec-lead` specialist owns the intake and feature-definition lifecycle.
3. `brainstorm/<slug>.md` is the only pre-spec intake ledger. Keep `status: brainstorm|promoted` and `spec_path:` there instead of creating extra state files.
4. Project-level principles in `.github/crew/principles.md` serve as the constitution.
5. `spec.md` must be technology-agnostic. Maximum 3 `[NEEDS CLARIFICATION]` markers, prioritized: scope > security > UX > technical.
6. `spec.md` must pass a quality gate (all sections complete, requirements testable, no impl details) before `plan.md` is written.
7. During intake and feature definition, `@spec-lead` is the planning authority for `brainstorm/<slug>.md` and `specs/<feature>/` artifacts; after import, `@lead` owns implementation architecture unless the user overrides it.
8. Definition packages do not go to `@tester` by default. Use `@lead` for architecture sanity and `@reviewer` for optional independent readiness judgment.
9. `@crew start working` is the normal handoff into Beads. It may import promoted brainstorms automatically. Explicit `@crew import tasks from specs/<feature>/ into Beads` is a manual fallback.

Tracked execution is optional until `@crew start working` or a manual import. Crew may still define and refine features under `brainstorm/` and `specs/` without Beads; rules 10-18 apply once tasks are imported into Beads.

10. Beads is the source of truth for pending and completed execution work.
11. Once tasks are imported into Beads, do not continue tracking from `tasks.md` or use the brainstorm file as the live execution board.
12. `@crew status` is read-only. It may report promoted features waiting for execution, but it must not import or mutate work state.
13. Use `bd ready --json` to find executable work.
14. Use `bd update <id> --claim --json` before starting work.
15. Close finished work with `bd close <id> --reason "Completed: <summary>" --json`.
16. If new work is discovered, create a linked Beads issue.
17. Always use `--json` flag with bd commands for reliable output parsing.
18. When multiple ready tasks are truly independent, Crew may dispatch them in parallel as an internal coordination decision.

## Skill Awareness

All agents — coordinator and specialists — should check for relevant skills
before starting work:

1. Check `.github/skills/project/SKILL.md` for project conventions.
2. Scan `.github/skills/` for any skill whose description matches the task.
3. Load matching skills and follow their guidance.
4. Treat `using-git-worktrees` as opt-in only; load it when the user explicitly asks for worktree or isolated-branch setup.

## Operational Discipline

1. For bugs, failing tests, and unexpected behavior, use `systematic-debugging` before proposing or implementing fixes.
2. Before claiming work is complete, fixed, passing, or ready, use `verification-before-completion` and rely on fresh evidence.
3. When receiving review feedback or rejection findings, use `receiving-code-review` before implementing or disputing the requested changes.
4. `test-driven-development` is available as an optional implementation aid when the user explicitly wants tests-first work, when project conventions require it, or when a bugfix benefits from a regression-first workflow.

## Conflict Resolution

When specialists disagree on a design or implementation choice:

1. The current planning authority has final say on structure and design questions.
2. The current quality authority has final say on acceptance and readiness.
3. If the disagreement crosses both domains or authority is unassigned, escalate to the user.

## Change Closure

- For feature-definition artifacts under `specs/<feature>/`, default to `@spec-lead` -> optional `@lead` architecture sanity -> optional `@reviewer` readiness judgment.
- For implementation and other executable artifacts, default to implementation -> verification (usually `@tester`, if present) -> quality authority (if assigned) unless the user explicitly asks for lighter handling.
- For direct answers, roster updates, memory updates, and other Crew-maintenance work, avoid forcing the full delivery pipeline.
- Any completion claim must be backed by fresh verification evidence.

## Project Stance

- Respect existing project conventions.
- Ask concise clarification questions when requirements are materially incomplete.
- Avoid introducing process overhead for simple tasks.
- Keep new agents narrow and useful instead of creating overlapping roles.
- Keep new skills reusable and scoped to recurring patterns, not one-off tasks.
- Keep memory entries concise, durable, and worth reusing.
- Routing and authority adapt to the current roster; there are no permanent defaults.
